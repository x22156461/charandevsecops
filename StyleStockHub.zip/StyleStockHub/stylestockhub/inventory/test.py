import CallGraph

generator = CallGraph.CallGraphGenerator()
generator.generate("C:/Users/nelat/Desktop/StyleStockHub/stylestockhub/inventory/views.py")