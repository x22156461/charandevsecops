from django.contrib import admin
from .models import Inventory
# Register your models here.

admin.site.register(Inventory)
